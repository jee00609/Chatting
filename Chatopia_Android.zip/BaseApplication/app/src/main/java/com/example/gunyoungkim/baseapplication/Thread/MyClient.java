/*
package com.example.gunyoungkim.baseapplication.Thread;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MyClient extends Activity {
    Button button1;
    private Socket socket;  //소켓생성
    BufferedReader in = null;      //서버로부터 온 데이터를 읽는다.
    PrintWriter out = null;        //서버에 데이터를 전송한다.
    EditText input;         //화면구성
    Button button;          //화면구성
    TextView output,chat_text;        //화면구성
    String data;
    Intent intent;
    String id;              //id 변수
    String receive;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.client);

        intent = getIntent();               // 인텐드를 받는다(메인 액티비티에서 넘긴 id)

        //start
        input = (EditText) findViewById(R.id.sendtext); // 글자입력칸(에디트텍스트)을 찾는다.
        button = (Button) findViewById(R.id.button1); // 버튼을 찾는다.

        showMessage();

        //메세지 전송 버튼 누른 경우
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                // 인텐트로 받은 아이디 저장
                id = intent.getStringExtra("id");
                out.println(id);

                //data 변수에 우리가 입력한 메세지를 저장한다.
                data = input.getText().toString(); //글자입력칸에 있는 글자를 String 형태로 받아서 data에 저장



                chat_text = (TextView) findViewById(R.id.chat_text);
                if (data != null) { // 만약 데이타가 입력된 것이라면
                    // 스크롤뷰(채팅창)에 데이터 출력
                    //서버로 부터 받은 메세지 receive 변수에 저장
                    try {
                        //우리가 만든 자바 서버에 메세지 전송
                        out.println(data);

                        //오토 플러시 적용되었지만
                        //그래도 다시 flush()실행하기!
                        out.flush();

                        //사용자가 보낸 메세지 창에 띄우기
                        receive = in.readLine();
                        chat_text.append(id+"::"+receive + "\n");
                    } catch (Exception e) {
                        e.getMessage();
                    }
                }
            }
        });

        Thread thread = new Thread() {    //worker 를 Thread 로 생성
            public void run() { //스레드 실행구문
                try {
                    //소켓을 생성
                    socket = new Socket("117.17.142.133", 3001); //소켓생성

                    //입출력 스트림 설정
                    //서버에서 메세지 읽어올 때  or  서버에 메세지 보낼 때 필요
                    out = new PrintWriter(socket.getOutputStream(), true); //데이터를 전송시 stream 형태로 변환하여                                                                                                                       //전송한다.
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream())); //데이터 수신시 stream을 받아들인다.

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        };
        thread.start();//스레드 실행하기
    }

    public void showMessage()
    {
        try {
            //사용자가 보낸 메세지 창에 띄우기
            receive = in.readLine();
            chat_text.append(id + "::" + receive + "\n");
        }
        catch(Exception e)
        {}
    }

    @Override
    //앱 종료시
    protected void onStop() {
        super.onStop();
        try {
            socket.close(); //소켓을 닫는다.
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
*/


package com.example.gunyoungkim.baseapplication.Thread;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MyClient extends Activity {
    private Socket socket;  //소켓생성
    BufferedReader in = null;      //서버로부터 온 데이터를 읽는다.
    PrintWriter out = null;        //서버에 데이터를 전송한다.
    EditText input;         //화면구성
    Button button;          //화면구성
    TextView output, chat_text;        //화면구성
    Intent intent;
    String id, data, receive, intro;
    String fromothers;
    Thread message;
    Timer timer = new Timer();
    ScrollView scrollView;  // 스크롤바
    Runnable showmessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.client);


        intent = getIntent();               // 인텐드를 받는다(메인 액티비티에서 넘긴 id)
        // 인텐트로 받은 아이디 저장
        id = intent.getStringExtra("id");
        //start
        input = (EditText) findViewById(R.id.sendtext); // 글자입력칸(에디트텍스트)을 찾는다.
        button = (Button) findViewById(R.id.button1); // 버튼을 찾는다.

        chat_text = (TextView) findViewById(R.id.chat_text);
        scrollView = (ScrollView) findViewById(R.id.scrollView);


        // 전송 완료 버튼 누른 경우
        // 순수하게 전송완료 기능만 한다
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                //data 변수에 우리가 입력한 메세지를 저장한다.
                data = input.getText().toString(); //글자입력칸에 있는 글자를 String 형태로 받아서 data에 저장

                if (data != null) {

                    //서버로 부터 받은 메세지 receive 변수에 저장
                    try {
                        //우리가 만든 자바 서버에 메세지 전송
                        out.println(data);

                    } catch (Exception e) {
                        e.getMessage();
                    }

                }

            }
        });


        //반복적으로 수신 버퍼의 내용 출력
        //타이머태스크 객체 생성하여
        //이 객체의 run함수에 다른사용자로 부터 온 모든 메세지를 chat_text에 출력하여 보여준다.
       /* final TimerTask msgtask=new TimerTask()
        {
            @Override
            public void run()
            {
                String fromothers;
                try
                {
                    //fromothers라는 변수에 bufferedreader로 부터
                    // 읽은 내용을 String형식으로 저장 & chat_text에 추가하는 방식으로 출력
                    fromothers = in.readLine();
                    chat_text.append(fromothers+"\n\n");
                }
                catch(Exception e){}

            }
        };*/

        //반복적으로 수신 버퍼의 내용 출력
        //타이머태스크 객체 생성하여
        //이 객체의 run함수에 다른사용자로 부터 온 모든 메세지를 chat_text에 출력하여 보여준다.
        final Runnable showmessage = new Runnable() {
            @Override
            public void run() {
                try {
                    //fromothers라는 변수에 bufferedreader로 부터
                    // 읽은 내용을 String형식으로 저장 & chat_text에 추가하는 방식으로 출력
                    fromothers = in.readLine();
                    chat_text.append(fromothers + "\n\n");
                } catch (Exception e) {
                }
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);   // 밑으로 스크롤해준다.
            }
        };


        //소켓 설정 & 스트림 설정 스레드 실행구문
        //아이디 입력하고 나서 바로 실행됨
        Thread thread = new Thread() {
            public void run() {
                try {
                    //소켓을 생성&서버와의 연결 시도
                    socket = new Socket("192.168.0.23", 3001);

                    //입출력 스트림 설정
                    //서버에서 메세지 읽어올 때  or  서버에 메세지 보낼 때 필요
                    out = new PrintWriter(socket.getOutputStream(), true); //데이터를 전송시 stream 형태로 변환하여                                                                                                                       //전송한다.
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream())); //데이터 수신시 stream을 받아들인다.
                } catch (IOException e)//예외 처리
                {
                    e.printStackTrace();
                }

                //서버한테 아이디 전송
                out.println(id);

                //맨 처음에 입장 안내문 출력
                //Intro();


                 //fromothers라는 변수에 bufferedreader로 부터
                // 읽은 내용을 String형식으로 저장 & chat_text에 추가하는 방식으로 출력
                while (true)
                {
                    //맨 처음에 입장 안내문 출력
                    Intro();
                    try
                    {
                        fromothers = in.readLine();
                        if (fromothers != null) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    chat_text.append(fromothers + "\n\n");
                                    scrollView.fullScroll(ScrollView.FOCUS_DOWN);   // 밑으로 스크롤해준다.
                                }
                            });
                        }
                } catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    ;
    //스레드 시작
        thread.start();
}

    //그냥 맨 처음에 입장 안내문 읽어오기 때문에 intro로 이름 지음
    public void Intro() {
        try {
            intro = in.readLine();
            chat_text.append(intro + "\n");
        } catch (Exception e) {
            e.getMessage();
        }
    }


    @Override
    //앱 종료시
    protected void onStop() {
        super.onStop();
        try {
            socket.close(); //소켓을 닫는다.
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}